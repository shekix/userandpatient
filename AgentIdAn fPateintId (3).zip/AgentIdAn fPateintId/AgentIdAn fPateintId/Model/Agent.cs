﻿using System.ComponentModel.DataAnnotations;

namespace AgentIdAn_fPateintId.Model
{
    public class Agent
    {
        [Key]
        public int AId { get; set; }
        public string? AgentId { get; set; }
        public string?  Name    { get; set; }
    }
}
