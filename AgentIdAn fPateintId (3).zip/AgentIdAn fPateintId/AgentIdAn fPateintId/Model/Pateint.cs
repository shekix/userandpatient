﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AgentIdAn_fPateintId.Model
{
    public class Pateint
    {
        [Key]
        public int PId { get; set; }
        public string PateintId { get; set; }
        public string Name { get; set; }
        [ForeignKey("Agent")]
        public int AgentId { get; set; }
        public Agent Agent { get; set; }
    }
}
