﻿namespace AgentIdAn_fPateintId
{
    public class AgentDto
    {
        public int AId { get; set; }
        public string? Name { get; set; }
    }
}
