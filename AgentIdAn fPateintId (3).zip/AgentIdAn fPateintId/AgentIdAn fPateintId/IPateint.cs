﻿using AgentIdAn_fPateintId.Model;

namespace AgentIdAn_fPateintId
{
    public interface IPateint
    {
        string CreatePost(Pateint pateint);
        List<Pateint> GetPateintList();    
    }
}
