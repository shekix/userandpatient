﻿using AgentIdAn_fPateintId.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AgentIdAn_fPateintId.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AgentController : ControllerBase
    {
        private readonly IAgent agent;

        public AgentController(IAgent agent)
        {
            this.agent = agent;
        }
        [HttpPost]
        public async Task<IActionResult> GetPost(AgentDto agent)
        {
            var model =await this.agent.CreateAgenet(agent);
            return Ok(model);
        }
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(this.agent.GetAllAgents());
        }
    }
}
