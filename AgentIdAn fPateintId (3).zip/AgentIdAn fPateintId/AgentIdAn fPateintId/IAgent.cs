﻿using AgentIdAn_fPateintId.Model;

namespace AgentIdAn_fPateintId
{
    public interface IAgent
    {
        Task<string> CreateAgenet(AgentDto agent);

        List<Agent> GetAllAgents();
    }
}
