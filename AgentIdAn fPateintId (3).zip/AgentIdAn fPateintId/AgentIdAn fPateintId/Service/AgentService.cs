﻿using AgentIdAn_fPateintId.Data;
using AgentIdAn_fPateintId.Model;
using Microsoft.EntityFrameworkCore;

namespace AgentIdAn_fPateintId.Service
{
    public class AgentService : IAgent
    {
        private readonly AppDbContext _dbContext;

        public AgentService(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<string> CreateAgenet(AgentDto agent)
        {
            var lastAgent = await _dbContext.Agent.OrderByDescending(a => a.AgentId).FirstOrDefaultAsync();
            string newAgentId;

            if (lastAgent == null)
            {
                // Initialize if the table is empty
                newAgentId = "TE0001";
            }
            else
            {
                // Extract numeric part from last AgentId
                int numericPart = int.Parse(lastAgent.AgentId.Substring(2));
                // Increment and format with leading zeros
                newAgentId = $"TE{(numericPart + 1).ToString("D4")}";
            }

            // Create and add the new agent
            var model = _dbContext.Agent.Add(new Agent
            {
                AgentId = newAgentId,
                Name = agent.Name,
            });

            // Save changes to the database
            await _dbContext.SaveChangesAsync();

            return  model.Entity.ToString();


        }

        public List<Agent> GetAllAgents()
        {
            return _dbContext.Agent.ToList();
        }
    }
}
