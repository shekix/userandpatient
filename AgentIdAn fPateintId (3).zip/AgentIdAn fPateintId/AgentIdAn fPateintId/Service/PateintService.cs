﻿using AgentIdAn_fPateintId.Model;

namespace AgentIdAn_fPateintId.Service
{
    public class PateintService : IPateint
    {
        public string CreatePost(Pateint pateint)
        {
            throw new NotImplementedException();
        }

        public List<Pateint> GetPateintList()
        {
            throw new NotImplementedException();
        }
    }
}
