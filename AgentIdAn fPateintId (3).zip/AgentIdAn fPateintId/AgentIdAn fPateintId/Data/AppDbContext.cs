﻿using AgentIdAn_fPateintId.Model;
using Microsoft.EntityFrameworkCore;

namespace AgentIdAn_fPateintId.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> dbContext ): base( dbContext ) { }
        
        public DbSet<Agent> Agent {  get; set; }

        public DbSet<Pateint> Pateint { get; set; }
    }
}
